# 🚀 Flash API SDK

SDK JavaScript oficial da Flash API - Multi-sessão WhatsApp

[![Node.js](https://img.shields.io/badge/Node.js->=18-339933?style=for-the-badge&logo=node.js)](https://nodejs.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](LICENSE)
[![npm version](https://img.shields.io/npm/v/flash-api-sdk?style=for-the-badge)](https://www.npmjs.com/package/flash-api-sdk)

## 📋 Sumário

- [Características](#características)
- [Instalação](#instalação)
- [Início Rápido](#início-rápido)
- [Autenticação](#autenticação)
- [Recursos](#recursos)
- [Exemplos](#exemplos)
- [WebSocket](#websocket)
- [Tratamento de Erros](#tratamento-de-erros)
- [API Reference](#api-reference)
- [FAQ](#faq)
- [Contribuindo](#contribuindo)
- [Licença](#licença)

## ✨ Características

- ✅ **100% JavaScript** - Sem TypeScript, sem compilação
- ✅ **Node.js >= 18** - Compatível com CommonJS e ESM
- ✅ **Multi-sessão** - Múltiplas instâncias do WhatsApp
- ✅ **WebSocket** - Eventos em tempo real
- ✅ **Retry automático** - Com backoff exponencial
- ✅ **HTTP Client** - Wrapper moderno com interceptadores
- ✅ **Validação** - Parâmetros obrigatórios verificados
- ✅ **Tratamento de erros** - Classes de erro customizadas
- ✅ **TypeScript definitions** - Autocompletar em IDEs

## 📦 Instalação

### npm

```bash
npm install flash-api-sdk
```
