import FlashApi from "./src/index.js";


const client = new FlashApi({
    baseUrl: 'http://localhost:3000',
    apiKey: 'sua-chave-api',
});

// Enviar mensagem
await client.chat.sendText({
    jid: '5511999999999@s.whatsapp.net',
    text: 'Olá mundo! 🚀',
});